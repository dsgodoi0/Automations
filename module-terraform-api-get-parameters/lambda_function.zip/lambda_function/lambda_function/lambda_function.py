import boto3
import json

ssm = boto3.client('ssm', region_name='us-east-1')
# from inspect import Parameter
next = None


def get_resources_from(ssm_details):
    results = ssm_details['Parameters']
    resources = [result for result in results]
    next_token = ssm_details.get('NextToken', None)
    return resources, next_token


def getNames(path=""):
    ssm = boto3.client('ssm', region_name='us-east-1')
    next_token = ' '
    resources = []
    listNames = []
    
    if path == "/hidden":
        path = "/"
        while next_token is not None:
            ssm_details = ssm.describe_parameters(MaxResults=50, NextToken=next_token)
            current_batch, next_token = get_resources_from(ssm_details)
            resources += current_batch
        # print(resources)
        # print('done')
        for item in resources:
            listNames.append(item["Name"])
    elif path == "/":
        listNames.append("invalido")
    else:
        listNames.append(path)
        

    return listNames


def getValues(listNames):
    listaValores = []
    for item in listNames:
        try:
            response = ssm.get_parameter(Name=item)["Parameter"]["Value"]
            response = response.replace('\n', '\\n')
            listaValores.append(response)
        except:
            listaValores.append("Valor Inválido")

    return listaValores

def lambda_handler(event, context):
    names = getNames(path=event['path'])
    values = getValues(names)
    response = dict()
    for i in range(len(names)):
        response[names[i]]=values[i]
    json_object=json.dumps(response)
    return {
        'statusCode': 200,
        'headers': {"content-type": "application/json"},
        'body': json_object
    }